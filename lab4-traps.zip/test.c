#include <stdio.h>
#include <arpa/inet.h>
int main(){
    // unsigned int i = 0x00646c72;
    unsigned int i = 0x726c6400;
	// printf("x=%d y=%d\n", 3);
    unsigned int j = ntohl(i);
     printf("H%x Wo%s", 57616, &j);
}